%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% this function implemets the LOOSFS and GLGS gene selection algorithms
% selectindex --------- the index of selected features
% data ---------------- a sample-by-feature matrix for training data, with corresponding labels in the last column
% SelectedFeatureNo --- the number of features to be selected
% AS ------------------ Algorithm switch, 1 for LOOSFS, 2 for GLGS
% Parameter ----------- the parameter that need to be predefined, 
% If using LOOSFS, Parameter is the predefined regularization parameter gama
% If using GLGS, Parameter is the iterations of gradient descent, usually set as 200
% In our latest experiments, conducting filter feature selection before employing GLGS/LOOSFS does not deterioate
% classification accuracy, but accelarates the whole selection process significantly. Therefore,a filter method (using Fisher's ratio) is 
% integrated in this version priory to the original GLGS/LOOSFS algorithm described in our paper.
% By Ke Tang (03/14/2005)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [selectindex]=geneselection(data,SelectedFeatureNo,AS,Parameter);

if AS==1
   [selectindex]=loosfs(data,SelectedFeatureNo,Parameter);
else
   [selectindex]=glgs(data,SelectedFeatureNo,Parameter);
end

