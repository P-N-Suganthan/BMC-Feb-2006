/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 06 20:09:28 2006
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-x" "-W" "mex" "-L" "C"
 * "-t" "-T" "link:mexlibrary" "libmatlbmx.mlib" "glgs" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#include "libmatlb.h"
#include "glgs.h"
#include "corrcoef.h"
#include "countele.h"
#include "mean.h"
#include "prestd.h"
#include "repmat.h"
#include "std.h"

extern _mex_information _mex_info;

static mexFunctionTableEntry function_table[1]
  = { { "glgs", mlxGlgs, 3, 1, &_local_function_table_glgs } };

static _mexInitTermTableEntry init_term_table[1]
  = { { InitializeModule_glgs, TerminateModule_glgs } };

/*
 * The function "Mstd" is the MATLAB callback version of the "std" function
 * from file "c:\matlab6p5p1\toolbox\matlab\datafun\std.m". It performs a
 * callback to MATLAB to run the "std" function, and passes any resulting
 * output arguments back to its calling function.
 */
static mxArray * Mstd(int nargout_,
                      mxArray * x,
                      mxArray * flag,
                      mxArray * dim) {
    mxArray * y = NULL;
    mclFevalCallMATLAB(
      mclNVarargout(nargout_, 0, &y, NULL), "std", x, flag, dim, NULL);
    return y;
}

/*
 * The function "Mrepmat" is the MATLAB callback version of the "repmat"
 * function from file "c:\matlab6p5p1\toolbox\matlab\elmat\repmat.m". It
 * performs a callback to MATLAB to run the "repmat" function, and passes any
 * resulting output arguments back to its calling function.
 */
static mxArray * Mrepmat(int nargout_, mxArray * A, mxArray * M, mxArray * N) {
    mxArray * B = NULL;
    mclFevalCallMATLAB(
      mclNVarargout(nargout_, 0, &B, NULL), "repmat", A, M, N, NULL);
    return B;
}

/*
 * The function "Mprestd" is the MATLAB callback version of the "prestd"
 * function from file "c:\matlab6p5p1\toolbox\nnet\nnet\prestd.m". It performs
 * a callback to MATLAB to run the "prestd" function, and passes any resulting
 * output arguments back to its calling function.
 */
static mxArray * Mprestd(mxArray * * meanp,
                         mxArray * * stdp,
                         mxArray * * tn,
                         mxArray * * meant,
                         mxArray * * stdt,
                         int nargout_,
                         mxArray * p,
                         mxArray * t) {
    mxArray * pn = NULL;
    mclFevalCallMATLAB(
      mclNVarargout(nargout_, 0, &pn, meanp, stdp, tn, meant, stdt, NULL),
      "prestd",
      p, t, NULL);
    return pn;
}

/*
 * The function "Mmean" is the MATLAB callback version of the "mean" function
 * from file "c:\matlab6p5p1\toolbox\matlab\datafun\mean.m". It performs a
 * callback to MATLAB to run the "mean" function, and passes any resulting
 * output arguments back to its calling function.
 */
static mxArray * Mmean(int nargout_, mxArray * x, mxArray * dim) {
    mxArray * y = NULL;
    mclFevalCallMATLAB(
      mclNVarargout(nargout_, 0, &y, NULL), "mean", x, dim, NULL);
    return y;
}

/*
 * The function "Mcountele" is the MATLAB callback version of the "countele"
 * function from file "c:\matlab6p5p1\prtools\knn\countele.m". It performs a
 * callback to MATLAB to run the "countele" function, and passes any resulting
 * output arguments back to its calling function.
 */
static mxArray * Mcountele(mxArray * * element_count,
                           int nargout_,
                           mxArray * in) {
    mxArray * sorted_element = NULL;
    mclFevalCallMATLAB(
      mclNVarargout(nargout_, 0, &sorted_element, element_count, NULL),
      "countele",
      in, NULL);
    return sorted_element;
}

/*
 * The function "Mcorrcoef" is the MATLAB callback version of the "corrcoef"
 * function from file "c:\matlab6p5p1\toolbox\matlab\datafun\corrcoef.m". It
 * performs a callback to MATLAB to run the "corrcoef" function, and passes any
 * resulting output arguments back to its calling function.
 */
static mxArray * Mcorrcoef(mxArray * * p,
                           mxArray * * rlo,
                           mxArray * * rup,
                           int nargout_,
                           mxArray * x,
                           mxArray * varargin) {
    mxArray * r = NULL;
    mclFevalCallMATLAB(
      mclNVarargout(nargout_, 0, &r, p, rlo, rup, NULL),
      "corrcoef",
      x, mlfIndexRef(varargin, "{?}", mlfCreateColonIndex()), NULL);
    return r;
}

/*
 * The function "mexLibrary" is a Compiler-generated mex wrapper, suitable for
 * building a MEX-function. It initializes any persistent variables as well as
 * a function table for use by the feval function. It then calls the function
 * "mlxGlgs". Finally, it clears the feval table and exits.
 */
mex_information mexLibrary(void) {
    mclMexLibraryInit();
    return &_mex_info;
}

_mex_information _mex_info
  = { 1, 1, function_table, 0, NULL, 0, NULL, 1, init_term_table };

/*
 * The function "mlfStd" contains the normal interface for the "std" M-function
 * from file "c:\matlab6p5p1\toolbox\matlab\datafun\std.m" (lines 0-0). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfStd(mxArray * x, mxArray * flag, mxArray * dim) {
    int nargout = 1;
    mxArray * y = NULL;
    mlfEnterNewContext(0, 3, x, flag, dim);
    y = Mstd(nargout, x, flag, dim);
    mlfRestorePreviousContext(0, 3, x, flag, dim);
    return mlfReturnValue(y);
}

/*
 * The function "mlxStd" contains the feval interface for the "std" M-function
 * from file "c:\matlab6p5p1\toolbox\matlab\datafun\std.m" (lines 0-0). The
 * feval function calls the implementation version of std through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxStd(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: std Line: 1 Column: 1 The function \"std\""
            " was called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: std Line: 1 Column: 1 The function \"std\""
            " was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mstd(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfRepmat" contains the normal interface for the "repmat"
 * M-function from file "c:\matlab6p5p1\toolbox\matlab\elmat\repmat.m" (lines
 * 0-0). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfRepmat(mxArray * A, mxArray * M, mxArray * N) {
    int nargout = 1;
    mxArray * B = NULL;
    mlfEnterNewContext(0, 3, A, M, N);
    B = Mrepmat(nargout, A, M, N);
    mlfRestorePreviousContext(0, 3, A, M, N);
    return mlfReturnValue(B);
}

/*
 * The function "mlxRepmat" contains the feval interface for the "repmat"
 * M-function from file "c:\matlab6p5p1\toolbox\matlab\elmat\repmat.m" (lines
 * 0-0). The feval function calls the implementation version of repmat through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
void mlxRepmat(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: repmat Line: 1 Column: "
            "1 The function \"repmat\" was called with mor"
            "e than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: repmat Line: 1 Column: "
            "1 The function \"repmat\" was called with mor"
            "e than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mrepmat(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfPrestd" contains the normal interface for the "prestd"
 * M-function from file "c:\matlab6p5p1\toolbox\nnet\nnet\prestd.m" (lines
 * 0-0). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfPrestd(mxArray * * meanp,
                    mxArray * * stdp,
                    mxArray * * tn,
                    mxArray * * meant,
                    mxArray * * stdt,
                    mxArray * p,
                    mxArray * t) {
    int nargout = 1;
    mxArray * pn = NULL;
    mxArray * meanp__ = NULL;
    mxArray * stdp__ = NULL;
    mxArray * tn__ = NULL;
    mxArray * meant__ = NULL;
    mxArray * stdt__ = NULL;
    mlfEnterNewContext(5, 2, meanp, stdp, tn, meant, stdt, p, t);
    if (meanp != NULL) {
        ++nargout;
    }
    if (stdp != NULL) {
        ++nargout;
    }
    if (tn != NULL) {
        ++nargout;
    }
    if (meant != NULL) {
        ++nargout;
    }
    if (stdt != NULL) {
        ++nargout;
    }
    pn = Mprestd(&meanp__, &stdp__, &tn__, &meant__, &stdt__, nargout, p, t);
    mlfRestorePreviousContext(5, 2, meanp, stdp, tn, meant, stdt, p, t);
    if (meanp != NULL) {
        mclCopyOutputArg(meanp, meanp__);
    } else {
        mxDestroyArray(meanp__);
    }
    if (stdp != NULL) {
        mclCopyOutputArg(stdp, stdp__);
    } else {
        mxDestroyArray(stdp__);
    }
    if (tn != NULL) {
        mclCopyOutputArg(tn, tn__);
    } else {
        mxDestroyArray(tn__);
    }
    if (meant != NULL) {
        mclCopyOutputArg(meant, meant__);
    } else {
        mxDestroyArray(meant__);
    }
    if (stdt != NULL) {
        mclCopyOutputArg(stdt, stdt__);
    } else {
        mxDestroyArray(stdt__);
    }
    return mlfReturnValue(pn);
}

/*
 * The function "mlxPrestd" contains the feval interface for the "prestd"
 * M-function from file "c:\matlab6p5p1\toolbox\nnet\nnet\prestd.m" (lines
 * 0-0). The feval function calls the implementation version of prestd through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
void mlxPrestd(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[6];
    int i;
    if (nlhs > 6) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: prestd Line: 1 Column: "
            "1 The function \"prestd\" was called with mor"
            "e than the declared number of outputs (6)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: prestd Line: 1 Column: "
            "1 The function \"prestd\" was called with mor"
            "e than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 6; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0]
      = Mprestd(
          &mplhs[1],
          &mplhs[2],
          &mplhs[3],
          &mplhs[4],
          &mplhs[5],
          nlhs,
          mprhs[0],
          mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 6 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 6; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "mlfMean" contains the normal interface for the "mean"
 * M-function from file "c:\matlab6p5p1\toolbox\matlab\datafun\mean.m" (lines
 * 0-0). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfMean(mxArray * x, mxArray * dim) {
    int nargout = 1;
    mxArray * y = NULL;
    mlfEnterNewContext(0, 2, x, dim);
    y = Mmean(nargout, x, dim);
    mlfRestorePreviousContext(0, 2, x, dim);
    return mlfReturnValue(y);
}

/*
 * The function "mlxMean" contains the feval interface for the "mean"
 * M-function from file "c:\matlab6p5p1\toolbox\matlab\datafun\mean.m" (lines
 * 0-0). The feval function calls the implementation version of mean through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
void mlxMean(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: mean Line: 1 Column: 1 The function \"mean\""
            " was called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: mean Line: 1 Column: 1 The function \"mean"
            "\" was called with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mmean(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCountele" contains the normal interface for the "countele"
 * M-function from file "c:\matlab6p5p1\prtools\knn\countele.m" (lines 0-0).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfCountele(mxArray * * element_count, mxArray * in) {
    int nargout = 1;
    mxArray * sorted_element = NULL;
    mxArray * element_count__ = NULL;
    mlfEnterNewContext(1, 1, element_count, in);
    if (element_count != NULL) {
        ++nargout;
    }
    sorted_element = Mcountele(&element_count__, nargout, in);
    mlfRestorePreviousContext(1, 1, element_count, in);
    if (element_count != NULL) {
        mclCopyOutputArg(element_count, element_count__);
    } else {
        mxDestroyArray(element_count__);
    }
    return mlfReturnValue(sorted_element);
}

/*
 * The function "mlxCountele" contains the feval interface for the "countele"
 * M-function from file "c:\matlab6p5p1\prtools\knn\countele.m" (lines 0-0).
 * The feval function calls the implementation version of countele through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxCountele(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: countele Line: 1 Column:"
            " 1 The function \"countele\" was called with m"
            "ore than the declared number of outputs (2)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: countele Line: 1 Column:"
            " 1 The function \"countele\" was called with m"
            "ore than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcountele(&mplhs[1], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}

/*
 * The function "mlfNCorrcoef" contains the nargout interface for the
 * "corrcoef" M-function from file
 * "c:\matlab6p5p1\toolbox\matlab\datafun\corrcoef.m" (lines 0-0). This
 * interface is only produced if the M-function uses the special variable
 * "nargout". The nargout interface allows the number of requested outputs to
 * be specified via the nargout argument, as opposed to the normal interface
 * which dynamically calculates the number of outputs based on the number of
 * non-NULL inputs it receives. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
mxArray * mlfNCorrcoef(int nargout,
                       mxArray * * p,
                       mxArray * * rlo,
                       mxArray * * rup,
                       mxArray * x,
                       ...) {
    mxArray * varargin = NULL;
    mxArray * r = NULL;
    mxArray * p__ = NULL;
    mxArray * rlo__ = NULL;
    mxArray * rup__ = NULL;
    mlfVarargin(&varargin, x, 0);
    mlfEnterNewContext(3, -2, p, rlo, rup, x, varargin);
    r = Mcorrcoef(&p__, &rlo__, &rup__, nargout, x, varargin);
    mlfRestorePreviousContext(3, 1, p, rlo, rup, x);
    mxDestroyArray(varargin);
    if (p != NULL) {
        mclCopyOutputArg(p, p__);
    } else {
        mxDestroyArray(p__);
    }
    if (rlo != NULL) {
        mclCopyOutputArg(rlo, rlo__);
    } else {
        mxDestroyArray(rlo__);
    }
    if (rup != NULL) {
        mclCopyOutputArg(rup, rup__);
    } else {
        mxDestroyArray(rup__);
    }
    return mlfReturnValue(r);
}

/*
 * The function "mlfCorrcoef" contains the normal interface for the "corrcoef"
 * M-function from file "c:\matlab6p5p1\toolbox\matlab\datafun\corrcoef.m"
 * (lines 0-0). This function processes any input arguments and passes them to
 * the implementation version of the function, appearing above.
 */
mxArray * mlfCorrcoef(mxArray * * p,
                      mxArray * * rlo,
                      mxArray * * rup,
                      mxArray * x,
                      ...) {
    mxArray * varargin = NULL;
    int nargout = 1;
    mxArray * r = NULL;
    mxArray * p__ = NULL;
    mxArray * rlo__ = NULL;
    mxArray * rup__ = NULL;
    mlfVarargin(&varargin, x, 0);
    mlfEnterNewContext(3, -2, p, rlo, rup, x, varargin);
    if (p != NULL) {
        ++nargout;
    }
    if (rlo != NULL) {
        ++nargout;
    }
    if (rup != NULL) {
        ++nargout;
    }
    r = Mcorrcoef(&p__, &rlo__, &rup__, nargout, x, varargin);
    mlfRestorePreviousContext(3, 1, p, rlo, rup, x);
    mxDestroyArray(varargin);
    if (p != NULL) {
        mclCopyOutputArg(p, p__);
    } else {
        mxDestroyArray(p__);
    }
    if (rlo != NULL) {
        mclCopyOutputArg(rlo, rlo__);
    } else {
        mxDestroyArray(rlo__);
    }
    if (rup != NULL) {
        mclCopyOutputArg(rup, rup__);
    } else {
        mxDestroyArray(rup__);
    }
    return mlfReturnValue(r);
}

/*
 * The function "mlfVCorrcoef" contains the void interface for the "corrcoef"
 * M-function from file "c:\matlab6p5p1\toolbox\matlab\datafun\corrcoef.m"
 * (lines 0-0). The void interface is only produced if the M-function uses the
 * special variable "nargout", and has at least one output. The void interface
 * function specifies zero output arguments to the implementation version of
 * the function, and in the event that the implementation version still returns
 * an output (which, in MATLAB, would be assigned to the "ans" variable), it
 * deallocates the output. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlfVCorrcoef(mxArray * x, ...) {
    mxArray * varargin = NULL;
    mxArray * r = NULL;
    mxArray * p = NULL;
    mxArray * rlo = NULL;
    mxArray * rup = NULL;
    mlfVarargin(&varargin, x, 0);
    mlfEnterNewContext(0, -2, x, varargin);
    r = Mcorrcoef(&p, &rlo, &rup, 0, x, varargin);
    mlfRestorePreviousContext(0, 1, x);
    mxDestroyArray(varargin);
    mxDestroyArray(r);
    mxDestroyArray(p);
    mxDestroyArray(rlo);
}

/*
 * The function "mlxCorrcoef" contains the feval interface for the "corrcoef"
 * M-function from file "c:\matlab6p5p1\toolbox\matlab\datafun\corrcoef.m"
 * (lines 0-0). The feval function calls the implementation version of corrcoef
 * through this function. This function processes any input arguments and
 * passes them to the implementation version of the function, appearing above.
 */
void mlxCorrcoef(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[4];
    int i;
    if (nlhs > 4) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: corrcoef Line: 1 Column:"
            " 1 The function \"corrcoef\" was called with m"
            "ore than the declared number of outputs (4)."),
          NULL);
    }
    for (i = 0; i < 4; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mprhs[1] = NULL;
    mlfAssign(&mprhs[1], mclCreateVararginCell(nrhs - 1, prhs + 1));
    mplhs[0]
      = Mcorrcoef(&mplhs[1], &mplhs[2], &mplhs[3], nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 4 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 4; ++i) {
        mxDestroyArray(mplhs[i]);
    }
    mxDestroyArray(mprhs[1]);
}
