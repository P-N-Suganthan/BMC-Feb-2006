/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 06 20:09:28 2006
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-x" "-W" "mex" "-L" "C"
 * "-t" "-T" "link:mexlibrary" "libmatlbmx.mlib" "glgs" 
 */
#include "glgs.h"
#include "corrcoef.h"
#include "countele.h"
#include "libmatlbm.h"
#include "mean.h"
#include "prestd.h"
#include "repmat.h"
#include "std.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;
static mxArray * _mxarray3_;
static mxArray * _mxarray4_;

static mxChar _array6_[2] = { 'l', 'k' };
static mxArray * _mxarray5_;
static mxArray * _mxarray7_;

static mxChar _array9_[30] = { 'G', 'r', 'a', 'd', 'i', 'e', 'n', 't',
                               ' ', 't', 'e', 'r', 'm', 'i', 'n', 'a',
                               't', 'e', ' ', 'e', 'a', 'r', 'l', 'i',
                               'e', 'r', '.', '.', '.', ' ' };
static mxArray * _mxarray8_;
static double _ieee_minusinf_;
static mxArray * _mxarray10_;

void InitializeModule_glgs(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeDouble(2.0);
    _mxarray2_ = mclInitializeDouble(1000.0);
    _mxarray3_ = mclInitializeDouble(.5);
    _mxarray4_ = mclInitializeDouble(0.0);
    _mxarray5_ = mclInitializeString(2, _array6_);
    _mxarray7_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _mxarray8_ = mclInitializeString(30, _array9_);
    _ieee_minusinf_ = mclGetMinusInf();
    _mxarray10_ = mclInitializeDouble(_ieee_minusinf_);
}

void TerminateModule_glgs(void) {
    mxDestroyArray(_mxarray10_);
    mxDestroyArray(_mxarray8_);
    mxDestroyArray(_mxarray7_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * mlfGlgs_lk(mxArray * kernel_type,
                            mxArray * data1,
                            mxArray * data2);
static void mlxGlgs_lk(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]);
static mxArray * Mglgs(int nargout_,
                       mxArray * data,
                       mxArray * SelectedFeatureNo,
                       mxArray * IterationTime);
static mxArray * Mglgs_lk(int nargout_,
                          mxArray * kernel_type,
                          mxArray * data1,
                          mxArray * data2);

static mexFunctionTableEntry local_function_table_[1]
  = { { "lk", mlxGlgs_lk, 3, 1, NULL } };

_mexLocalFunctionTable _local_function_table_glgs
  = { 1, local_function_table_ };

/*
 * The function "mlfGlgs" contains the normal interface for the "glgs"
 * M-function from file "g:\paper\self\bmc\public code\glgs.m" (lines 1-121).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfGlgs(mxArray * data,
                  mxArray * SelectedFeatureNo,
                  mxArray * IterationTime) {
    int nargout = 1;
    mxArray * selectindex = NULL;
    mlfEnterNewContext(0, 3, data, SelectedFeatureNo, IterationTime);
    selectindex = Mglgs(nargout, data, SelectedFeatureNo, IterationTime);
    mlfRestorePreviousContext(0, 3, data, SelectedFeatureNo, IterationTime);
    return mlfReturnValue(selectindex);
}

/*
 * The function "mlxGlgs" contains the feval interface for the "glgs"
 * M-function from file "g:\paper\self\bmc\public code\glgs.m" (lines 1-121).
 * The feval function calls the implementation version of glgs through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxGlgs(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: glgs Line: 10 Column: 1 The function \"glgs"
            "\" was called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: glgs Line: 10 Column: 1 The function \"glgs"
            "\" was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mglgs(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfGlgs_lk" contains the normal interface for the "glgs/lk"
 * M-function from file "g:\paper\self\bmc\public code\glgs.m" (lines 121-123).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static mxArray * mlfGlgs_lk(mxArray * kernel_type,
                            mxArray * data1,
                            mxArray * data2) {
    int nargout = 1;
    mxArray * kernelmatrix = NULL;
    mlfEnterNewContext(0, 3, kernel_type, data1, data2);
    kernelmatrix = Mglgs_lk(nargout, kernel_type, data1, data2);
    mlfRestorePreviousContext(0, 3, kernel_type, data1, data2);
    return mlfReturnValue(kernelmatrix);
}

/*
 * The function "mlxGlgs_lk" contains the feval interface for the "glgs/lk"
 * M-function from file "g:\paper\self\bmc\public code\glgs.m" (lines 121-123).
 * The feval function calls the implementation version of glgs/lk through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
static void mlxGlgs_lk(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: glgs/lk Line: 121 Column"
            ": 1 The function \"glgs/lk\" was called with m"
            "ore than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: glgs/lk Line: 121 Column"
            ": 1 The function \"glgs/lk\" was called with m"
            "ore than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mglgs_lk(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mglgs" is the implementation version of the "glgs" M-function
 * from file "g:\paper\self\bmc\public code\glgs.m" (lines 1-121). It contains
 * the actual compiled code for that M-function. It is a static function and
 * must only be called from one of the interface functions, appearing below.
 */
/*
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * % this function implemets the GLGS gene selection algorithm
 * % selectindex --------- the index of selected features
 * % data ---------------- a sample-by-feature matrix for training data, with corresponding labels in the last column
 * % SelectedFeatureNo --- the number of features to be selected
 * % IterationTime ------- parameter of the gradient descent, preliminary IterationTime=200
 * % By Ke Tang (03/14/2005)
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * 
 * function [selectindex]=glgs(data,SelectedFeatureNo,IterationTime)
 */
static mxArray * Mglgs(int nargout_,
                       mxArray * data,
                       mxArray * SelectedFeatureNo,
                       mxArray * IterationTime) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_glgs);
    mxArray * temp_ = NULL;
    mxArray * selectindex = NULL;
    mxArray * constrvector = NULL;
    mxArray * tempv1 = NULL;
    mxArray * correlationmatrix = NULL;
    mxArray * importancevalue = NULL;
    mxArray * tempvector6 = NULL;
    mxArray * tempvector5 = NULL;
    mxArray * i1 = NULL;
    mxArray * gra = NULL;
    mxArray * told = NULL;
    mxArray * f = NULL;
    mxArray * tempv = NULL;
    mxArray * tempvector2 = NULL;
    mxArray * Hii = NULL;
    mxArray * H = NULL;
    mxArray * M = NULL;
    mxArray * ans = NULL;
    mxArray * alphas = NULL;
    mxArray * tempvector1 = NULL;
    mxArray * tempvector = NULL;
    mxArray * tempmatrix = NULL;
    mxArray * omega = NULL;
    mxArray * kernelmatrix = NULL;
    mxArray * gamma = NULL;
    mxArray * fweights = NULL;
    mxArray * kernel_type = NULL;
    mxArray * i = NULL;
    mxArray * evaop = NULL;
    mxArray * fhd = NULL;
    mxArray * t = NULL;
    mxArray * trdata = NULL;
    mxArray * size_pc = NULL;
    mxArray * greater = NULL;
    mxArray * frac_var = NULL;
    mxArray * total_variance = NULL;
    mxArray * var = NULL;
    mxArray * v = NULL;
    mxArray * s = NULL;
    mxArray * TransMat = NULL;
    mxArray * stdp = NULL;
    mxArray * meanp = NULL;
    mxArray * pn = NULL;
    mxArray * LearningRate = NULL;
    mxArray * traindata = NULL;
    mxArray * fisherindex = NULL;
    mxArray * index = NULL;
    mxArray * t1 = NULL;
    mxArray * bwratio = NULL;
    mxArray * w = NULL;
    mxArray * b = NULL;
    mxArray * nc = NULL;
    mxArray * classlabel = NULL;
    mxArray * Y = NULL;
    mxArray * d = NULL;
    mxArray * n = NULL;
    mclCopyArray(&data);
    mclCopyArray(&SelectedFeatureNo);
    mclCopyArray(&IterationTime);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% preprocess data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
     * [n,d]=size(data);
     */
    mlfSize(mlfVarargout(&n, &d, NULL), mclVa(data, "data"), NULL);
    /*
     * Y=data(:,d);
     */
    mlfAssign(
      &Y,
      mclArrayRef2(mclVa(data, "data"), mlfCreateColonIndex(), mclVv(d, "d")));
    /*
     * [classlabel,nc]=countele(data(:,d));
     */
    mlfAssign(
      &classlabel,
      mlfCountele(
        &nc,
        mclArrayRef2(
          mclVa(data, "data"), mlfCreateColonIndex(), mclVv(d, "d"))));
    /*
     * b=(mean(data(find(data(:,d)==classlabel(1)),1:d-1))-mean(data(find(data(:,d)==classlabel(2)),1:d-1))).^2;
     */
    mlfAssign(
      &b,
      mlfPower(
        mclMinus(
          mlfMean(
            mclArrayRef2(
              mclVa(data, "data"),
              mlfFind(
                NULL,
                NULL,
                mclEq(
                  mclArrayRef2(
                    mclVa(data, "data"), mlfCreateColonIndex(), mclVv(d, "d")),
                  mclIntArrayRef1(mclVv(classlabel, "classlabel"), 1))),
              mlfColon(_mxarray0_, mclMinus(mclVv(d, "d"), _mxarray0_), NULL)),
            NULL),
          mlfMean(
            mclArrayRef2(
              mclVa(data, "data"),
              mlfFind(
                NULL,
                NULL,
                mclEq(
                  mclArrayRef2(
                    mclVa(data, "data"), mlfCreateColonIndex(), mclVv(d, "d")),
                  mclIntArrayRef1(mclVv(classlabel, "classlabel"), 2))),
              mlfColon(_mxarray0_, mclMinus(mclVv(d, "d"), _mxarray0_), NULL)),
            NULL)),
        _mxarray1_));
    /*
     * w=(std(data(find(data(:,d)==classlabel(1)),1:d-1))).^2+(std(data(find(data(:,d)==classlabel(2)),1:d-1))).^2;
     */
    mlfAssign(
      &w,
      mclPlus(
        mlfPower(
          mlfStd(
            mclArrayRef2(
              mclVa(data, "data"),
              mlfFind(
                NULL,
                NULL,
                mclEq(
                  mclArrayRef2(
                    mclVa(data, "data"), mlfCreateColonIndex(), mclVv(d, "d")),
                  mclIntArrayRef1(mclVv(classlabel, "classlabel"), 1))),
              mlfColon(_mxarray0_, mclMinus(mclVv(d, "d"), _mxarray0_), NULL)),
            NULL,
            NULL),
          _mxarray1_),
        mlfPower(
          mlfStd(
            mclArrayRef2(
              mclVa(data, "data"),
              mlfFind(
                NULL,
                NULL,
                mclEq(
                  mclArrayRef2(
                    mclVa(data, "data"), mlfCreateColonIndex(), mclVv(d, "d")),
                  mclIntArrayRef1(mclVv(classlabel, "classlabel"), 2))),
              mlfColon(_mxarray0_, mclMinus(mclVv(d, "d"), _mxarray0_), NULL)),
            NULL,
            NULL),
          _mxarray1_)));
    /*
     * bwratio=b./w;
     */
    mlfAssign(&bwratio, mclRdivide(mclVv(b, "b"), mclVv(w, "w")));
    /*
     * [t1,index]=sort(-bwratio);
     */
    mlfAssign(&t1, mlfSort(&index, mclUminus(mclVv(bwratio, "bwratio")), NULL));
    /*
     * fisherindex=index(1:1000);
     */
    mlfAssign(
      &fisherindex,
      mclArrayRef1(
        mclVv(index, "index"), mlfColon(_mxarray0_, _mxarray2_, NULL)));
    /*
     * traindata=[data(:,fisherindex),Y];   
     */
    mlfAssign(
      &traindata,
      mlfHorzcat(
        mclArrayRef2(
          mclVa(data, "data"),
          mlfCreateColonIndex(),
          mclVv(fisherindex, "fisherindex")),
        mclVv(Y, "Y"),
        NULL));
    /*
     * [n,d]=size(traindata);
     */
    mlfSize(mlfVarargout(&n, &d, NULL), mclVv(traindata, "traindata"), NULL);
    /*
     * LearningRate=0.5;
     */
    mlfAssign(&LearningRate, _mxarray3_);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PCA procedure %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
     * [pn,meanp,stdp] = prestd(traindata(:,1:d-1)');
     */
    mlfAssign(
      &pn,
      mlfPrestd(
        &meanp,
        &stdp,
        NULL,
        NULL,
        NULL,
        mlfCtranspose(
          mclArrayRef2(
            mclVv(traindata, "traindata"),
            mlfCreateColonIndex(),
            mlfColon(_mxarray0_, mclMinus(mclVv(d, "d"), _mxarray0_), NULL))),
        NULL));
    /*
     * % Use the singular value decomposition to compute the principal components
     * [TransMat,s,v] = svd(pn,0);
     */
    mlfAssign(&TransMat, mlfSvd(&s, &v, mclVv(pn, "pn"), _mxarray4_));
    /*
     * 
     * % Compute the variance of each principal component
     * var = diag(s).^2/(d-2);
     */
    mlfAssign(
      &var,
      mclMrdivide(
        mlfPower(mlfDiag(mclVv(s, "s"), NULL), _mxarray1_),
        mclMinus(mclVv(d, "d"), _mxarray1_)));
    /*
     * 
     * % Compute total variance and fractional variance
     * total_variance = sum(var);
     */
    mlfAssign(&total_variance, mlfSum(mclVv(var, "var"), NULL));
    /*
     * frac_var = var./total_variance;
     */
    mlfAssign(
      &frac_var,
      mclRdivide(mclVv(var, "var"), mclVv(total_variance, "total_variance")));
    /*
     * 
     * % Find the componets which contribute more than min_frac of the total variance
     * greater = (frac_var > 0);
     */
    mlfAssign(&greater, mclGt(mclVv(frac_var, "frac_var"), _mxarray4_));
    /*
     * size_pc = sum(greater);
     */
    mlfAssign(&size_pc, mlfSum(mclVv(greater, "greater"), NULL));
    /*
     * 
     * % Reduce the transformation matrix appropriately
     * TransMat = TransMat(:,1:size_pc);
     */
    mlfAssign(
      &TransMat,
      mclArrayRef2(
        mclVv(TransMat, "TransMat"),
        mlfCreateColonIndex(),
        mlfColon(_mxarray0_, mclVv(size_pc, "size_pc"), NULL)));
    /*
     * 
     * % Transform the data
     * trdata = [traindata(:,1:d-1)*TransMat,traindata(:,d)];
     */
    mlfAssign(
      &trdata,
      mlfHorzcat(
        mclMtimes(
          mclArrayRef2(
            mclVv(traindata, "traindata"),
            mlfCreateColonIndex(),
            mlfColon(_mxarray0_, mclMinus(mclVv(d, "d"), _mxarray0_), NULL)),
          mclVv(TransMat, "TransMat")),
        mclArrayRef2(
          mclVv(traindata, "traindata"), mlfCreateColonIndex(), mclVv(d, "d")),
        NULL));
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% gradient procedure %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
     * %%% gradient optimization procedure %%%
     * t=[0,zeros(1,size_pc)];
     */
    mlfAssign(
      &t,
      mlfHorzcat(
        _mxarray4_,
        mlfZeros(_mxarray0_, mclVv(size_pc, "size_pc"), NULL),
        NULL));
    /*
     * 
     * fhd=str2func('lk'); % select linear kernel
     */
    mlfAssign(&fhd, mlfStr2func(_mxarray5_));
    /*
     * evaop=ones(1,1+size_pc);
     */
    mlfAssign(
      &evaop,
      mlfOnes(
        _mxarray0_, mclPlus(_mxarray0_, mclVv(size_pc, "size_pc")), NULL));
    /*
     * 
     * for i=1:IterationTime
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVa(IterationTime, "IterationTime"));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray7_);
        } else {
            /*
             * kernel_type=[0 0 0 0 exp(t(1))];
             * fweights=exp(t(2:size_pc+1));
             * gamma=kernel_type(5);
             * kernelmatrix=feval(fhd,kernel_type,trdata(:,1:size_pc).*(ones(n,1)*fweights),trdata(:,1:size_pc));
             * omega=zeros(n);
             * omega(1:n,1:n)=(Y*Y').*kernelmatrix+eye(n,n)/gamma;
             * tempmatrix=[0,Y';Y,omega];
             * tempvector=[0;ones(n,1)];
             * tempvector1=tempmatrix\tempvector;
             * alphas(:,1)=tempvector1(2:n+1);
             * clear temp*;
             * 
             * % calculate inverse of H
             * M=[omega,Y;Y',0];
             * tempvector=[ones(n,1);0];
             * tempvector1=inv(M)*[eye(n,n),zeros(n,1);zeros(1,n),0]*inv(M)*tempvector;
             * H=kernelmatrix+eye(n,n)/gamma;
             * H=[H,ones(n,1);ones(1,n),0];
             * Hii=diag(inv(H));
             * tempvector2=diag(inv(H)*[eye(n,n),zeros(n,1);zeros(1,n),0]*inv(H));
             * tempv=1-alphas./repmat(Hii(1:n),1,size(alphas,2));
             * tempv=2*tempv;
             * f(i)=sum(1./(1+exp(tempv)));
             * if i>1 & f(i)>f(i-1)
             * t=told;
             * fprintf (1, 'Gradient terminate earlier... ');
             * i
             * break
             * end
             * gra(i,1)=2*exp(-t(1))*(exp(tempv)./((1+exp(tempv)).^2))'*(tempvector1(1:n)./Hii(1:n)-(alphas.*tempvector2(1:n))./(Hii(1:n).^2));    % calculate gradient
             * told(1)=t(1);
             * t(1)=t(1)-LearningRate*gra(i,1);
             * for i1=1:size_pc
             * tempvector5=inv(M)*[(Y*Y').*(trdata(:,i1)*trdata(:,i1)'),zeros(n,1);zeros(1,n),0]*inv(M)*tempvector;
             * tempvector6=diag(inv(H)*[trdata(:,i1)*trdata(:,i1)',zeros(n,1);zeros(1,n),0]*inv(H));
             * gra(i,i1+1)=2*exp(t(i1+1))*(exp(tempv)./((1+exp(tempv)).^2))'*(-tempvector5(1:n)./Hii(1:n)+(alphas.*tempvector6(1:n))./(Hii(1:n).^2));   % calculate gradient
             * told(i1+1)=t(i1+1);
             * t(i1+1)=t(i1+1)-LearningRate*gra(i,i1+1);
             * end
             * end
             */
            for (; ; ) {
                mlfAssign(
                  &kernel_type,
                  mlfHorzcat(
                    _mxarray4_,
                    _mxarray4_,
                    _mxarray4_,
                    _mxarray4_,
                    mlfExp(mclIntArrayRef1(mclVv(t, "t"), 1)),
                    NULL));
                mlfAssign(
                  &fweights,
                  mlfExp(
                    mclArrayRef1(
                      mclVv(t, "t"),
                      mlfColon(
                        _mxarray1_,
                        mclPlus(mclVv(size_pc, "size_pc"), _mxarray0_),
                        NULL))));
                mlfAssign(
                  &gamma,
                  mclIntArrayRef1(mclVv(kernel_type, "kernel_type"), 5));
                mlfAssign(
                  &kernelmatrix,
                  mlfFeval(
                    mclValueVarargout(),
                    mclVv(fhd, "fhd"),
                    mclVv(kernel_type, "kernel_type"),
                    mclTimes(
                      mclArrayRef2(
                        mclVv(trdata, "trdata"),
                        mlfCreateColonIndex(),
                        mlfColon(_mxarray0_, mclVv(size_pc, "size_pc"), NULL)),
                      mclMtimes(
                        mlfOnes(mclVv(n, "n"), _mxarray0_, NULL),
                        mclVv(fweights, "fweights"))),
                    mclArrayRef2(
                      mclVv(trdata, "trdata"),
                      mlfCreateColonIndex(),
                      mlfColon(_mxarray0_, mclVv(size_pc, "size_pc"), NULL)),
                    NULL));
                mlfAssign(&omega, mlfZeros(mclVv(n, "n"), NULL));
                mclArrayAssign2(
                  &omega,
                  mclPlus(
                    mclTimes(
                      mlf_times_transpose(
                        mclVv(Y, "Y"), mclVv(Y, "Y"), _mxarray1_),
                      mclVv(kernelmatrix, "kernelmatrix")),
                    mclMrdivide(
                      mlfEye(mclVv(n, "n"), mclVv(n, "n")),
                      mclVv(gamma, "gamma"))),
                  mlfColon(_mxarray0_, mclVv(n, "n"), NULL),
                  mlfColon(_mxarray0_, mclVv(n, "n"), NULL));
                mlfAssign(
                  &tempmatrix,
                  mlfVertcat(
                    mlfHorzcat(_mxarray4_, mlfCtranspose(mclVv(Y, "Y")), NULL),
                    mlfHorzcat(mclVv(Y, "Y"), mclVv(omega, "omega"), NULL),
                    NULL));
                mlfAssign(
                  &tempvector,
                  mlfVertcat(
                    _mxarray4_,
                    mlfOnes(mclVv(n, "n"), _mxarray0_, NULL),
                    NULL));
                mlfAssign(
                  &tempvector1,
                  mlfMldivide(
                    mclVv(tempmatrix, "tempmatrix"),
                    mclVv(tempvector, "tempvector")));
                mclArrayAssign2(
                  &alphas,
                  mclArrayRef1(
                    mclVv(tempvector1, "tempvector1"),
                    mlfColon(
                      _mxarray1_, mclPlus(mclVv(n, "n"), _mxarray0_), NULL)),
                  mlfCreateColonIndex(),
                  _mxarray0_);
                mlfClear(&temp_, NULL);
                mlfAssign(
                  &M,
                  mlfVertcat(
                    mlfHorzcat(mclVv(omega, "omega"), mclVv(Y, "Y"), NULL),
                    mlfHorzcat(mlfCtranspose(mclVv(Y, "Y")), _mxarray4_, NULL),
                    NULL));
                mlfAssign(
                  &tempvector,
                  mlfVertcat(
                    mlfOnes(mclVv(n, "n"), _mxarray0_, NULL),
                    _mxarray4_,
                    NULL));
                mlfAssign(
                  &tempvector1,
                  mclMtimes(
                    mclMtimes(
                      mclMtimes(
                        mlfInv(mclVv(M, "M")),
                        mlfVertcat(
                          mlfHorzcat(
                            mlfEye(mclVv(n, "n"), mclVv(n, "n")),
                            mlfZeros(mclVv(n, "n"), _mxarray0_, NULL),
                            NULL),
                          mlfHorzcat(
                            mlfZeros(_mxarray0_, mclVv(n, "n"), NULL),
                            _mxarray4_,
                            NULL),
                          NULL)),
                      mlfInv(mclVv(M, "M"))),
                    mclVv(tempvector, "tempvector")));
                mlfAssign(
                  &H,
                  mclPlus(
                    mclVv(kernelmatrix, "kernelmatrix"),
                    mclMrdivide(
                      mlfEye(mclVv(n, "n"), mclVv(n, "n")),
                      mclVv(gamma, "gamma"))));
                mlfAssign(
                  &H,
                  mlfVertcat(
                    mlfHorzcat(
                      mclVv(H, "H"),
                      mlfOnes(mclVv(n, "n"), _mxarray0_, NULL),
                      NULL),
                    mlfHorzcat(
                      mlfOnes(_mxarray0_, mclVv(n, "n"), NULL),
                      _mxarray4_,
                      NULL),
                    NULL));
                mlfAssign(&Hii, mlfDiag(mlfInv(mclVv(H, "H")), NULL));
                mlfAssign(
                  &tempvector2,
                  mlfDiag(
                    mclMtimes(
                      mclMtimes(
                        mlfInv(mclVv(H, "H")),
                        mlfVertcat(
                          mlfHorzcat(
                            mlfEye(mclVv(n, "n"), mclVv(n, "n")),
                            mlfZeros(mclVv(n, "n"), _mxarray0_, NULL),
                            NULL),
                          mlfHorzcat(
                            mlfZeros(_mxarray0_, mclVv(n, "n"), NULL),
                            _mxarray4_,
                            NULL),
                          NULL)),
                      mlfInv(mclVv(H, "H"))),
                    NULL));
                mlfAssign(
                  &tempv,
                  mclMinus(
                    _mxarray0_,
                    mclRdivide(
                      mclVv(alphas, "alphas"),
                      mlfRepmat(
                        mclArrayRef1(
                          mclVv(Hii, "Hii"),
                          mlfColon(_mxarray0_, mclVv(n, "n"), NULL)),
                        _mxarray0_,
                        mlfSize(
                          mclValueVarargout(),
                          mclVv(alphas, "alphas"),
                          _mxarray1_)))));
                mlfAssign(&tempv, mclMtimes(_mxarray1_, mclVv(tempv, "tempv")));
                mclIntArrayAssign1(
                  &f,
                  mlfSum(
                    mclRdivide(
                      _mxarray0_,
                      mclPlus(_mxarray0_, mlfExp(mclVv(tempv, "tempv")))),
                    NULL),
                  v_);
                {
                    mxArray * a_ = mclInitialize(mclBoolToArray(v_ > 1));
                    if (mlfTobool(a_)
                        && mlfTobool(
                             mclAnd(
                               a_,
                               mclGt(
                                 mclIntArrayRef1(mclVv(f, "f"), v_),
                                 mclIntArrayRef1(mclVv(f, "f"), v_ - 1))))) {
                        mxDestroyArray(a_);
                        mlfAssign(&t, mclVv(told, "told"));
                        mclAssignAns(
                          &ans, mlfNFprintf(0, _mxarray0_, _mxarray8_, NULL));
                        mclPrintArray(mlfScalar(v_), "i");
                        break;
                    } else {
                        mxDestroyArray(a_);
                    }
                }
                mclIntArrayAssign2(
                  &gra,
                  mclMtimes(
                    mlf_times_transpose(
                      mclMtimes(
                        _mxarray1_,
                        mlfExp(mclUminus(mclIntArrayRef1(mclVv(t, "t"), 1)))),
                      mclRdivide(
                        mlfExp(mclVv(tempv, "tempv")),
                        mlfPower(
                          mclPlus(_mxarray0_, mlfExp(mclVv(tempv, "tempv"))),
                          _mxarray1_)),
                      _mxarray1_),
                    mclMinus(
                      mclRdivide(
                        mclArrayRef1(
                          mclVv(tempvector1, "tempvector1"),
                          mlfColon(_mxarray0_, mclVv(n, "n"), NULL)),
                        mclArrayRef1(
                          mclVv(Hii, "Hii"),
                          mlfColon(_mxarray0_, mclVv(n, "n"), NULL))),
                      mclRdivide(
                        mclTimes(
                          mclVv(alphas, "alphas"),
                          mclArrayRef1(
                            mclVv(tempvector2, "tempvector2"),
                            mlfColon(_mxarray0_, mclVv(n, "n"), NULL))),
                        mlfPower(
                          mclArrayRef1(
                            mclVv(Hii, "Hii"),
                            mlfColon(_mxarray0_, mclVv(n, "n"), NULL)),
                          _mxarray1_)))),
                  v_,
                  1);
                mclIntArrayAssign1(&told, mclIntArrayRef1(mclVv(t, "t"), 1), 1);
                mclIntArrayAssign1(
                  &t,
                  mclMinus(
                    mclIntArrayRef1(mclVv(t, "t"), 1),
                    mclMtimes(
                      mclVv(LearningRate, "LearningRate"),
                      mclIntArrayRef2(mclVv(gra, "gra"), v_, 1))),
                  1);
                {
                    int v_0 = mclForIntStart(1);
                    int e_0 = mclForIntEnd(mclVv(size_pc, "size_pc"));
                    if (v_0 > e_0) {
                        mlfAssign(&i1, _mxarray7_);
                    } else {
                        for (; ; ) {
                            mlfAssign(
                              &tempvector5,
                              mclMtimes(
                                mclMtimes(
                                  mclMtimes(
                                    mlfInv(mclVv(M, "M")),
                                    mlfVertcat(
                                      mlfHorzcat(
                                        mclTimes(
                                          mlf_times_transpose(
                                            mclVv(Y, "Y"),
                                            mclVv(Y, "Y"),
                                            _mxarray1_),
                                          mlf_times_transpose(
                                            mclArrayRef2(
                                              mclVv(trdata, "trdata"),
                                              mlfCreateColonIndex(),
                                              mlfScalar(v_0)),
                                            mclArrayRef2(
                                              mclVv(trdata, "trdata"),
                                              mlfCreateColonIndex(),
                                              mlfScalar(v_0)),
                                            _mxarray1_)),
                                        mlfZeros(
                                          mclVv(n, "n"), _mxarray0_, NULL),
                                        NULL),
                                      mlfHorzcat(
                                        mlfZeros(
                                          _mxarray0_, mclVv(n, "n"), NULL),
                                        _mxarray4_,
                                        NULL),
                                      NULL)),
                                  mlfInv(mclVv(M, "M"))),
                                mclVv(tempvector, "tempvector")));
                            mlfAssign(
                              &tempvector6,
                              mlfDiag(
                                mclMtimes(
                                  mclMtimes(
                                    mlfInv(mclVv(H, "H")),
                                    mlfVertcat(
                                      mlfHorzcat(
                                        mlf_times_transpose(
                                          mclArrayRef2(
                                            mclVv(trdata, "trdata"),
                                            mlfCreateColonIndex(),
                                            mlfScalar(v_0)),
                                          mclArrayRef2(
                                            mclVv(trdata, "trdata"),
                                            mlfCreateColonIndex(),
                                            mlfScalar(v_0)),
                                          _mxarray1_),
                                        mlfZeros(
                                          mclVv(n, "n"), _mxarray0_, NULL),
                                        NULL),
                                      mlfHorzcat(
                                        mlfZeros(
                                          _mxarray0_, mclVv(n, "n"), NULL),
                                        _mxarray4_,
                                        NULL),
                                      NULL)),
                                  mlfInv(mclVv(H, "H"))),
                                NULL));
                            mclIntArrayAssign2(
                              &gra,
                              mclMtimes(
                                mlf_times_transpose(
                                  mclMtimes(
                                    _mxarray1_,
                                    mlfExp(
                                      mclIntArrayRef1(mclVv(t, "t"), v_0 + 1))),
                                  mclRdivide(
                                    mlfExp(mclVv(tempv, "tempv")),
                                    mlfPower(
                                      mclPlus(
                                        _mxarray0_,
                                        mlfExp(mclVv(tempv, "tempv"))),
                                      _mxarray1_)),
                                  _mxarray1_),
                                mclPlus(
                                  mclRdivide(
                                    mclUminus(
                                      mclArrayRef1(
                                        mclVv(tempvector5, "tempvector5"),
                                        mlfColon(
                                          _mxarray0_, mclVv(n, "n"), NULL))),
                                    mclArrayRef1(
                                      mclVv(Hii, "Hii"),
                                      mlfColon(
                                        _mxarray0_, mclVv(n, "n"), NULL))),
                                  mclRdivide(
                                    mclTimes(
                                      mclVv(alphas, "alphas"),
                                      mclArrayRef1(
                                        mclVv(tempvector6, "tempvector6"),
                                        mlfColon(
                                          _mxarray0_, mclVv(n, "n"), NULL))),
                                    mlfPower(
                                      mclArrayRef1(
                                        mclVv(Hii, "Hii"),
                                        mlfColon(
                                          _mxarray0_, mclVv(n, "n"), NULL)),
                                      _mxarray1_)))),
                              v_,
                              v_0 + 1);
                            mclIntArrayAssign1(
                              &told,
                              mclIntArrayRef1(mclVv(t, "t"), v_0 + 1),
                              v_0 + 1);
                            mclIntArrayAssign1(
                              &t,
                              mclMinus(
                                mclIntArrayRef1(mclVv(t, "t"), v_0 + 1),
                                mclMtimes(
                                  mclVv(LearningRate, "LearningRate"),
                                  mclIntArrayRef2(
                                    mclVv(gra, "gra"), v_, v_0 + 1))),
                              v_0 + 1);
                            if (v_0 == e_0) {
                                break;
                            }
                            ++v_0;
                        }
                        mlfAssign(&i1, mlfScalar(v_0));
                    }
                }
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    /*
     * importancevalue=exp(t(2:size_pc+1))*abs(TransMat');
     */
    mlfAssign(
      &importancevalue,
      mclMtimes(
        mlfExp(
          mclArrayRef1(
            mclVv(t, "t"),
            mlfColon(
              _mxarray1_,
              mclPlus(mclVv(size_pc, "size_pc"), _mxarray0_),
              NULL))),
        mlfAbs(mlfCtranspose(mclVv(TransMat, "TransMat")))));
    /*
     * gamma=exp(t(1));
     */
    mlfAssign(&gamma, mlfExp(mclIntArrayRef1(mclVv(t, "t"), 1)));
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% selection procedure %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%        
     * 
     * % % directly select features based on loo accuracy
     * % [tempv1,tempv2]=sort(-importancevalue);
     * % selectindex=tempv2(1:SelectedFeatureNo);
     * 
     * %%% select features based on correlation and loo accuracy %%%
     * correlationmatrix=abs(corrcoef(traindata(:,1:d-1)))-eye(d-1,d-1);
     */
    mlfAssign(
      &correlationmatrix,
      mclMinus(
        mlfAbs(
          mlfNCorrcoef(
            1,
            NULL,
            NULL,
            NULL,
            mclArrayRef2(
              mclVv(traindata, "traindata"),
              mlfCreateColonIndex(),
              mlfColon(_mxarray0_, mclMinus(mclVv(d, "d"), _mxarray0_), NULL)),
            NULL)),
        mlfEye(
          mclMinus(mclVv(d, "d"), _mxarray0_),
          mclMinus(mclVv(d, "d"), _mxarray0_))));
    /*
     * tempv1=importancevalue+importancevalue*(correlationmatrix./(ones(d-1,1)*sum(correlationmatrix)))';
     */
    mlfAssign(
      &tempv1,
      mclPlus(
        mclVv(importancevalue, "importancevalue"),
        mlf_times_transpose(
          mclVv(importancevalue, "importancevalue"),
          mclRdivide(
            mclVv(correlationmatrix, "correlationmatrix"),
            mclMtimes(
              mlfOnes(mclMinus(mclVv(d, "d"), _mxarray0_), _mxarray0_, NULL),
              mlfSum(mclVv(correlationmatrix, "correlationmatrix"), NULL))),
          _mxarray1_)));
    /*
     * [t1,selectindex(1)]=max(tempv1);
     */
    mclFeval(
      mlfIndexVarargout(&t1, "", &selectindex, "(?)", _mxarray0_, NULL),
      mlxMax,
      mclVv(tempv1, "tempv1"),
      NULL);
    /*
     * for i=1:SelectedFeatureNo-1
     */
    {
        int v_ = mclForIntStart(1);
        int e_
          = mclForIntEnd(
              mclMinus(
                mclVa(SelectedFeatureNo, "SelectedFeatureNo"), _mxarray0_));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray7_);
        } else {
            /*
             * if i==1
             * constrvector=1-correlationmatrix(:,selectindex)';
             * constrvector(1,selectindex)=-inf*ones(1,i);
             * else
             * constrvector=1-max(correlationmatrix(:,selectindex)');
             * constrvector(1,selectindex)=-inf*ones(1,i);
             * end
             * [t1,selectindex(i+1)]=max(tempv1.*constrvector);
             * end
             */
            for (; ; ) {
                if (mclEqBool(mlfScalar(v_), _mxarray0_)) {
                    mlfAssign(
                      &constrvector,
                      mclMinus(
                        _mxarray0_,
                        mlfCtranspose(
                          mclArrayRef2(
                            mclVv(correlationmatrix, "correlationmatrix"),
                            mlfCreateColonIndex(),
                            mclVv(selectindex, "selectindex")))));
                    mclArrayAssign2(
                      &constrvector,
                      mclMtimes(
                        _mxarray10_, mlfOnes(_mxarray0_, mlfScalar(v_), NULL)),
                      _mxarray0_,
                      mclVv(selectindex, "selectindex"));
                } else {
                    mlfAssign(
                      &constrvector,
                      mclMinus(
                        _mxarray0_,
                        mlfMax(
                          NULL,
                          mlfCtranspose(
                            mclArrayRef2(
                              mclVv(correlationmatrix, "correlationmatrix"),
                              mlfCreateColonIndex(),
                              mclVv(selectindex, "selectindex"))),
                          NULL,
                          NULL)));
                    mclArrayAssign2(
                      &constrvector,
                      mclMtimes(
                        _mxarray10_, mlfOnes(_mxarray0_, mlfScalar(v_), NULL)),
                      _mxarray0_,
                      mclVv(selectindex, "selectindex"));
                }
                mclFeval(
                  mlfIndexVarargout(
                    &t1, "", &selectindex, "(?)", mlfScalar(v_ + 1), NULL),
                  mlxMax,
                  mclTimes(
                    mclVv(tempv1, "tempv1"),
                    mclVv(constrvector, "constrvector")),
                  NULL);
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    /*
     * selectindex=fisherindex(selectindex);
     */
    mlfAssign(
      &selectindex,
      mclArrayRef1(
        mclVv(fisherindex, "fisherindex"), mclVv(selectindex, "selectindex")));
    mclValidateOutput(selectindex, 1, nargout_, "selectindex", "glgs");
    mxDestroyArray(n);
    mxDestroyArray(d);
    mxDestroyArray(Y);
    mxDestroyArray(classlabel);
    mxDestroyArray(nc);
    mxDestroyArray(b);
    mxDestroyArray(w);
    mxDestroyArray(bwratio);
    mxDestroyArray(t1);
    mxDestroyArray(index);
    mxDestroyArray(fisherindex);
    mxDestroyArray(traindata);
    mxDestroyArray(LearningRate);
    mxDestroyArray(pn);
    mxDestroyArray(meanp);
    mxDestroyArray(stdp);
    mxDestroyArray(TransMat);
    mxDestroyArray(s);
    mxDestroyArray(v);
    mxDestroyArray(var);
    mxDestroyArray(total_variance);
    mxDestroyArray(frac_var);
    mxDestroyArray(greater);
    mxDestroyArray(size_pc);
    mxDestroyArray(trdata);
    mxDestroyArray(t);
    mxDestroyArray(fhd);
    mxDestroyArray(evaop);
    mxDestroyArray(i);
    mxDestroyArray(kernel_type);
    mxDestroyArray(fweights);
    mxDestroyArray(gamma);
    mxDestroyArray(kernelmatrix);
    mxDestroyArray(omega);
    mxDestroyArray(tempmatrix);
    mxDestroyArray(tempvector);
    mxDestroyArray(tempvector1);
    mxDestroyArray(alphas);
    mxDestroyArray(ans);
    mxDestroyArray(M);
    mxDestroyArray(H);
    mxDestroyArray(Hii);
    mxDestroyArray(tempvector2);
    mxDestroyArray(tempv);
    mxDestroyArray(f);
    mxDestroyArray(told);
    mxDestroyArray(gra);
    mxDestroyArray(i1);
    mxDestroyArray(tempvector5);
    mxDestroyArray(tempvector6);
    mxDestroyArray(importancevalue);
    mxDestroyArray(correlationmatrix);
    mxDestroyArray(tempv1);
    mxDestroyArray(constrvector);
    mxDestroyArray(IterationTime);
    mxDestroyArray(SelectedFeatureNo);
    mxDestroyArray(data);
    mxDestroyArray(temp_);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return selectindex;
    /*
     * 
     * %%% linear kernel %%%
     */
}

/*
 * The function "Mglgs_lk" is the implementation version of the "glgs/lk"
 * M-function from file "g:\paper\self\bmc\public code\glgs.m" (lines 121-123).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * function kernelmatrix=lk(kernel_type,data1,data2)
 */
static mxArray * Mglgs_lk(int nargout_,
                          mxArray * kernel_type,
                          mxArray * data1,
                          mxArray * data2) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_glgs);
    mxArray * kernelmatrix = NULL;
    mclCopyArray(&kernel_type);
    mclCopyArray(&data1);
    mclCopyArray(&data2);
    /*
     * 
     * kernelmatrix=data1*data2';
     */
    mlfAssign(
      &kernelmatrix,
      mlf_times_transpose(
        mclVa(data1, "data1"), mclVa(data2, "data2"), _mxarray1_));
    mclValidateOutput(kernelmatrix, 1, nargout_, "kernelmatrix", "glgs/lk");
    mxDestroyArray(data2);
    mxDestroyArray(data1);
    mxDestroyArray(kernel_type);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return kernelmatrix;
}
