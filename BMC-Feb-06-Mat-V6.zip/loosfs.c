/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 06 20:13:28 2006
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-x" "-W" "mex" "-L" "C"
 * "-t" "-T" "link:mexlibrary" "libmatlbmx.mlib" "loosfs" 
 */
#include "loosfs.h"
#include "countele.h"
#include "libmatlbm.h"
#include "mean.h"
#include "std.h"
static mxArray * _mxarray0_;
static mxArray * _mxarray1_;
static mxArray * _mxarray2_;
static mxArray * _mxarray3_;
static mxArray * _mxarray4_;
static double _ieee_minusinf_;
static mxArray * _mxarray5_;
static mxArray * _mxarray6_;

void InitializeModule_loosfs(void) {
    _mxarray0_ = mclInitializeDouble(1.0);
    _mxarray1_ = mclInitializeDouble(2.0);
    _mxarray2_ = mclInitializeDouble(1000.0);
    _mxarray3_ = mclInitializeDouble(0.0);
    _mxarray4_ = mclInitializeDoubleVector(0, 0, (double *)NULL);
    _ieee_minusinf_ = mclGetMinusInf();
    _mxarray5_ = mclInitializeDouble(_ieee_minusinf_);
    _mxarray6_ = mclInitializeDouble(6.0);
}

void TerminateModule_loosfs(void) {
    mxDestroyArray(_mxarray6_);
    mxDestroyArray(_mxarray5_);
    mxDestroyArray(_mxarray4_);
    mxDestroyArray(_mxarray3_);
    mxDestroyArray(_mxarray2_);
    mxDestroyArray(_mxarray1_);
    mxDestroyArray(_mxarray0_);
}

static mxArray * Mloosfs(int nargout_,
                         mxArray * data,
                         mxArray * SelectedFeatureNo,
                         mxArray * gamma);

_mexLocalFunctionTable _local_function_table_loosfs
  = { 0, (mexFunctionTableEntry *)NULL };

/*
 * The function "mlfLoosfs" contains the normal interface for the "loosfs"
 * M-function from file "g:\paper\self\bmc\public code\loosfs.m" (lines 1-63).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfLoosfs(mxArray * data,
                    mxArray * SelectedFeatureNo,
                    mxArray * gamma) {
    int nargout = 1;
    mxArray * selectindex = NULL;
    mlfEnterNewContext(0, 3, data, SelectedFeatureNo, gamma);
    selectindex = Mloosfs(nargout, data, SelectedFeatureNo, gamma);
    mlfRestorePreviousContext(0, 3, data, SelectedFeatureNo, gamma);
    return mlfReturnValue(selectindex);
}

/*
 * The function "mlxLoosfs" contains the feval interface for the "loosfs"
 * M-function from file "g:\paper\self\bmc\public code\loosfs.m" (lines 1-63).
 * The feval function calls the implementation version of loosfs through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxLoosfs(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: loosfs Line: 13 Column:"
            " 1 The function \"loosfs\" was called with mo"
            "re than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: loosfs Line: 13 Column:"
            " 1 The function \"loosfs\" was called with mo"
            "re than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mloosfs(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "Mloosfs" is the implementation version of the "loosfs"
 * M-function from file "g:\paper\self\bmc\public code\loosfs.m" (lines 1-63).
 * It contains the actual compiled code for that M-function. It is a static
 * function and must only be called from one of the interface functions,
 * appearing below.
 */
/*
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * % this function implemets the LOOC measure + SFS feature selection algorithm
 * % use linear kernel
 * % traindata ----------- a sample-by-feature matrix, with corresponding labels (1 or -1) in the last column
 * % gamma --------------- the predefined regularization parameter
 * % SelectedFeatureNo --- defines the number of features to be selected
 * % omega --------------- (y.*k(x))'*(y.*k(x))+eye(n,n)/gamma
 * % h ------------------- [(k(x))'*(k(x))+eye(n,n)/gamma,ones(n,1);ones(1,n),0]
 * % candidateindex ------ those features that are not selected before
 * % By Ke Tang (04/06/2005)
 * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 * 
 * function [selectindex] = loosfs(data,SelectedFeatureNo,gamma)
 */
static mxArray * Mloosfs(int nargout_,
                         mxArray * data,
                         mxArray * SelectedFeatureNo,
                         mxArray * gamma) {
    mexLocalFunctionTable save_local_function_table_
      = mclSetCurrentLocalFunctionTable(&_local_function_table_loosfs);
    mxArray * selectindex = NULL;
    mxArray * boundrecord = NULL;
    mxArray * tm2 = NULL;
    mxArray * tm1 = NULL;
    mxArray * lcbound = NULL;
    mxArray * loooutput = NULL;
    mxArray * tinvh = NULL;
    mxArray * alphas = NULL;
    mxArray * tinvomega = NULL;
    mxArray * j = NULL;
    mxArray * findex = NULL;
    mxArray * looac = NULL;
    mxArray * looa = NULL;
    mxArray * i = NULL;
    mxArray * invh = NULL;
    mxArray * invomega = NULL;
    mxArray * candidateindex = NULL;
    mxArray * traindata = NULL;
    mxArray * fisherindex = NULL;
    mxArray * index = NULL;
    mxArray * t1 = NULL;
    mxArray * bwratio = NULL;
    mxArray * w = NULL;
    mxArray * b = NULL;
    mxArray * nc = NULL;
    mxArray * classlabel = NULL;
    mxArray * Y = NULL;
    mxArray * d = NULL;
    mxArray * n = NULL;
    mclCopyArray(&data);
    mclCopyArray(&SelectedFeatureNo);
    mclCopyArray(&gamma);
    /*
     * 
     * %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% preprocess data %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     
     * [n,d]=size(data);
     */
    mlfSize(mlfVarargout(&n, &d, NULL), mclVa(data, "data"), NULL);
    /*
     * Y=data(:,d);
     */
    mlfAssign(
      &Y,
      mclArrayRef2(mclVa(data, "data"), mlfCreateColonIndex(), mclVv(d, "d")));
    /*
     * [classlabel,nc]=countele(data(:,d));
     */
    mlfAssign(
      &classlabel,
      mlfCountele(
        &nc,
        mclArrayRef2(
          mclVa(data, "data"), mlfCreateColonIndex(), mclVv(d, "d"))));
    /*
     * b=(mean(data(find(data(:,d)==classlabel(1)),1:d-1))-mean(data(find(data(:,d)==classlabel(2)),1:d-1))).^2;
     */
    mlfAssign(
      &b,
      mlfPower(
        mclMinus(
          mlfMean(
            mclArrayRef2(
              mclVa(data, "data"),
              mlfFind(
                NULL,
                NULL,
                mclEq(
                  mclArrayRef2(
                    mclVa(data, "data"), mlfCreateColonIndex(), mclVv(d, "d")),
                  mclIntArrayRef1(mclVv(classlabel, "classlabel"), 1))),
              mlfColon(_mxarray0_, mclMinus(mclVv(d, "d"), _mxarray0_), NULL)),
            NULL),
          mlfMean(
            mclArrayRef2(
              mclVa(data, "data"),
              mlfFind(
                NULL,
                NULL,
                mclEq(
                  mclArrayRef2(
                    mclVa(data, "data"), mlfCreateColonIndex(), mclVv(d, "d")),
                  mclIntArrayRef1(mclVv(classlabel, "classlabel"), 2))),
              mlfColon(_mxarray0_, mclMinus(mclVv(d, "d"), _mxarray0_), NULL)),
            NULL)),
        _mxarray1_));
    /*
     * w=(std(data(find(data(:,d)==classlabel(1)),1:d-1))).^2+(std(data(find(data(:,d)==classlabel(2)),1:d-1))).^2;
     */
    mlfAssign(
      &w,
      mclPlus(
        mlfPower(
          mlfStd(
            mclArrayRef2(
              mclVa(data, "data"),
              mlfFind(
                NULL,
                NULL,
                mclEq(
                  mclArrayRef2(
                    mclVa(data, "data"), mlfCreateColonIndex(), mclVv(d, "d")),
                  mclIntArrayRef1(mclVv(classlabel, "classlabel"), 1))),
              mlfColon(_mxarray0_, mclMinus(mclVv(d, "d"), _mxarray0_), NULL)),
            NULL,
            NULL),
          _mxarray1_),
        mlfPower(
          mlfStd(
            mclArrayRef2(
              mclVa(data, "data"),
              mlfFind(
                NULL,
                NULL,
                mclEq(
                  mclArrayRef2(
                    mclVa(data, "data"), mlfCreateColonIndex(), mclVv(d, "d")),
                  mclIntArrayRef1(mclVv(classlabel, "classlabel"), 2))),
              mlfColon(_mxarray0_, mclMinus(mclVv(d, "d"), _mxarray0_), NULL)),
            NULL,
            NULL),
          _mxarray1_)));
    /*
     * bwratio=b./w;
     */
    mlfAssign(&bwratio, mclRdivide(mclVv(b, "b"), mclVv(w, "w")));
    /*
     * [t1,index]=sort(-bwratio);
     */
    mlfAssign(&t1, mlfSort(&index, mclUminus(mclVv(bwratio, "bwratio")), NULL));
    /*
     * fisherindex=index(1:1000);
     */
    mlfAssign(
      &fisherindex,
      mclArrayRef1(
        mclVv(index, "index"), mlfColon(_mxarray0_, _mxarray2_, NULL)));
    /*
     * traindata=[data(:,fisherindex),Y];   
     */
    mlfAssign(
      &traindata,
      mlfHorzcat(
        mclArrayRef2(
          mclVa(data, "data"),
          mlfCreateColonIndex(),
          mclVv(fisherindex, "fisherindex")),
        mclVv(Y, "Y"),
        NULL));
    /*
     * 
     * [n,d]=size(traindata);
     */
    mlfSize(mlfVarargout(&n, &d, NULL), mclVv(traindata, "traindata"), NULL);
    /*
     * candidateindex=ones(1,d-1);
     */
    mlfAssign(
      &candidateindex,
      mlfOnes(_mxarray0_, mclMinus(mclVv(d, "d"), _mxarray0_), NULL));
    /*
     * invomega=gamma*eye(n,n);
     */
    mlfAssign(
      &invomega,
      mclMtimes(mclVa(gamma, "gamma"), mlfEye(mclVv(n, "n"), mclVv(n, "n"))));
    /*
     * invh=inv([eye(n,n)/gamma,ones(n,1);ones(1,n),0]);
     */
    mlfAssign(
      &invh,
      mlfInv(
        mlfVertcat(
          mlfHorzcat(
            mclMrdivide(
              mlfEye(mclVv(n, "n"), mclVv(n, "n")), mclVa(gamma, "gamma")),
            mlfOnes(mclVv(n, "n"), _mxarray0_, NULL),
            NULL),
          mlfHorzcat(
            mlfOnes(_mxarray0_, mclVv(n, "n"), NULL), _mxarray3_, NULL),
          NULL)));
    /*
     * Y=traindata(:,d);
     */
    mlfAssign(
      &Y,
      mclArrayRef2(
        mclVv(traindata, "traindata"), mlfCreateColonIndex(), mclVv(d, "d")));
    /*
     * 
     * for i=1:SelectedFeatureNo
     */
    {
        int v_ = mclForIntStart(1);
        int e_ = mclForIntEnd(mclVa(SelectedFeatureNo, "SelectedFeatureNo"));
        if (v_ > e_) {
            mlfAssign(&i, _mxarray4_);
        } else {
            /*
             * looa=-inf;
             * looac=-inf;
             * findex=0;
             * for j=1:d-1
             * if candidateindex(j)~=0
             * tinvomega=invomega-invomega*(Y.*traindata(:,j))*(Y.*traindata(:,j))'*invomega/(1+(Y.*traindata(:,j))'*invomega*(Y.*traindata(:,j)));
             * alphas=tinvomega*ones(n,1)-Y'*tinvomega*ones(n,1)*tinvomega*Y/(Y'*tinvomega*Y);
             * tinvh=invh-invh*([traindata(:,j);0])*([traindata(:,j);0])'*invh/(1+([traindata(:,j);0])'*invh*([traindata(:,j);0]));
             * loooutput=1-alphas./diag(tinvh(1:n,1:n));
             * lcbound=sum(loooutput(find(loooutput<=0)));
             * if sum(sign(loooutput))>looa
             * looa=sum(sign(loooutput));
             * looac=lcbound;
             * tm1=tinvomega;
             * tm2=tinvh;
             * findex=j;
             * elseif sum(sign(loooutput))==looa & lcbound>looac
             * looac=lcbound;
             * tm1=tinvomega;
             * tm2=tinvh;
             * findex=j;
             * end
             * end
             * end
             * invomega=tm1;
             * invh=tm2;
             * candidateindex(findex)=0;
             * selectindex(i)=findex;
             * boundrecord(i)=looac;
             * end
             */
            for (; ; ) {
                mlfAssign(&looa, _mxarray5_);
                mlfAssign(&looac, _mxarray5_);
                mlfAssign(&findex, _mxarray3_);
                {
                    int v_0 = mclForIntStart(1);
                    int e_0 = mclForIntEnd(mclMinus(mclVv(d, "d"), _mxarray0_));
                    if (v_0 > e_0) {
                        mlfAssign(&j, _mxarray4_);
                    } else {
                        for (; ; ) {
                            if (mclNeBool(
                                  mclIntArrayRef1(
                                    mclVv(candidateindex, "candidateindex"),
                                    v_0),
                                  _mxarray3_)) {
                                mlfAssign(
                                  &tinvomega,
                                  mclMinus(
                                    mclVv(invomega, "invomega"),
                                    mclMrdivide(
                                      mclMtimes(
                                        mlf_times_transpose(
                                          mclMtimes(
                                            mclVv(invomega, "invomega"),
                                            mclTimes(
                                              mclVv(Y, "Y"),
                                              mclArrayRef2(
                                                mclVv(traindata, "traindata"),
                                                mlfCreateColonIndex(),
                                                mlfScalar(v_0)))),
                                          mclTimes(
                                            mclVv(Y, "Y"),
                                            mclArrayRef2(
                                              mclVv(traindata, "traindata"),
                                              mlfCreateColonIndex(),
                                              mlfScalar(v_0))),
                                          _mxarray1_),
                                        mclVv(invomega, "invomega")),
                                      mclPlus(
                                        _mxarray0_,
                                        mclMtimes(
                                          mlf_times_transpose(
                                            mclTimes(
                                              mclVv(Y, "Y"),
                                              mclArrayRef2(
                                                mclVv(traindata, "traindata"),
                                                mlfCreateColonIndex(),
                                                mlfScalar(v_0))),
                                            mclVv(invomega, "invomega"),
                                            _mxarray6_),
                                          mclTimes(
                                            mclVv(Y, "Y"),
                                            mclArrayRef2(
                                              mclVv(traindata, "traindata"),
                                              mlfCreateColonIndex(),
                                              mlfScalar(v_0))))))));
                                mlfAssign(
                                  &alphas,
                                  mclMinus(
                                    mclMtimes(
                                      mclVv(tinvomega, "tinvomega"),
                                      mlfOnes(mclVv(n, "n"), _mxarray0_, NULL)),
                                    mclMrdivide(
                                      mclMtimes(
                                        mclMtimes(
                                          mclMtimes(
                                            mlf_times_transpose(
                                              mclVv(Y, "Y"),
                                              mclVv(tinvomega, "tinvomega"),
                                              _mxarray6_),
                                            mlfOnes(
                                              mclVv(n, "n"), _mxarray0_, NULL)),
                                          mclVv(tinvomega, "tinvomega")),
                                        mclVv(Y, "Y")),
                                      mclMtimes(
                                        mlf_times_transpose(
                                          mclVv(Y, "Y"),
                                          mclVv(tinvomega, "tinvomega"),
                                          _mxarray6_),
                                        mclVv(Y, "Y")))));
                                mlfAssign(
                                  &tinvh,
                                  mclMinus(
                                    mclVv(invh, "invh"),
                                    mclMrdivide(
                                      mclMtimes(
                                        mlf_times_transpose(
                                          mclMtimes(
                                            mclVv(invh, "invh"),
                                            mlfVertcat(
                                              mclArrayRef2(
                                                mclVv(traindata, "traindata"),
                                                mlfCreateColonIndex(),
                                                mlfScalar(v_0)),
                                              _mxarray3_,
                                              NULL)),
                                          mlfVertcat(
                                            mclArrayRef2(
                                              mclVv(traindata, "traindata"),
                                              mlfCreateColonIndex(),
                                              mlfScalar(v_0)),
                                            _mxarray3_,
                                            NULL),
                                          _mxarray1_),
                                        mclVv(invh, "invh")),
                                      mclPlus(
                                        _mxarray0_,
                                        mclMtimes(
                                          mlf_times_transpose(
                                            mlfVertcat(
                                              mclArrayRef2(
                                                mclVv(traindata, "traindata"),
                                                mlfCreateColonIndex(),
                                                mlfScalar(v_0)),
                                              _mxarray3_,
                                              NULL),
                                            mclVv(invh, "invh"),
                                            _mxarray6_),
                                          mlfVertcat(
                                            mclArrayRef2(
                                              mclVv(traindata, "traindata"),
                                              mlfCreateColonIndex(),
                                              mlfScalar(v_0)),
                                            _mxarray3_,
                                            NULL))))));
                                mlfAssign(
                                  &loooutput,
                                  mclMinus(
                                    _mxarray0_,
                                    mclRdivide(
                                      mclVv(alphas, "alphas"),
                                      mlfDiag(
                                        mclArrayRef2(
                                          mclVv(tinvh, "tinvh"),
                                          mlfColon(
                                            _mxarray0_, mclVv(n, "n"), NULL),
                                          mlfColon(
                                            _mxarray0_, mclVv(n, "n"), NULL)),
                                        NULL))));
                                mlfAssign(
                                  &lcbound,
                                  mlfSum(
                                    mclArrayRef1(
                                      mclVv(loooutput, "loooutput"),
                                      mlfFind(
                                        NULL,
                                        NULL,
                                        mclLe(
                                          mclVv(loooutput, "loooutput"),
                                          _mxarray3_))),
                                    NULL));
                                if (mclGtBool(
                                      mlfSum(
                                        mlfSign(mclVv(loooutput, "loooutput")),
                                        NULL),
                                      mclVv(looa, "looa"))) {
                                    mlfAssign(
                                      &looa,
                                      mlfSum(
                                        mlfSign(mclVv(loooutput, "loooutput")),
                                        NULL));
                                    mlfAssign(
                                      &looac, mclVv(lcbound, "lcbound"));
                                    mlfAssign(
                                      &tm1, mclVv(tinvomega, "tinvomega"));
                                    mlfAssign(&tm2, mclVv(tinvh, "tinvh"));
                                    mlfAssign(&findex, mlfScalar(v_0));
                                } else {
                                    mxArray * a_
                                      = mclInitialize(
                                          mclEq(
                                            mlfSum(
                                              mlfSign(
                                                mclVv(loooutput, "loooutput")),
                                              NULL),
                                            mclVv(looa, "looa")));
                                    if (mlfTobool(a_)
                                        && mlfTobool(
                                             mclAnd(
                                               a_,
                                               mclGt(
                                                 mclVv(lcbound, "lcbound"),
                                                 mclVv(looac, "looac"))))) {
                                        mxDestroyArray(a_);
                                        mlfAssign(
                                          &looac, mclVv(lcbound, "lcbound"));
                                        mlfAssign(
                                          &tm1, mclVv(tinvomega, "tinvomega"));
                                        mlfAssign(&tm2, mclVv(tinvh, "tinvh"));
                                        mlfAssign(&findex, mlfScalar(v_0));
                                    } else {
                                        mxDestroyArray(a_);
                                    }
                                }
                            }
                            if (v_0 == e_0) {
                                break;
                            }
                            ++v_0;
                        }
                        mlfAssign(&j, mlfScalar(v_0));
                    }
                }
                mlfAssign(&invomega, mclVv(tm1, "tm1"));
                mlfAssign(&invh, mclVv(tm2, "tm2"));
                mclArrayAssign1(
                  &candidateindex, _mxarray3_, mclVv(findex, "findex"));
                mclIntArrayAssign1(&selectindex, mclVv(findex, "findex"), v_);
                mclIntArrayAssign1(&boundrecord, mclVv(looac, "looac"), v_);
                if (v_ == e_) {
                    break;
                }
                ++v_;
            }
            mlfAssign(&i, mlfScalar(v_));
        }
    }
    /*
     * selectindex=fisherindex(selectindex);
     */
    mlfAssign(
      &selectindex,
      mclArrayRef1(
        mclVv(fisherindex, "fisherindex"), mclVv(selectindex, "selectindex")));
    mclValidateOutput(selectindex, 1, nargout_, "selectindex", "loosfs");
    mxDestroyArray(n);
    mxDestroyArray(d);
    mxDestroyArray(Y);
    mxDestroyArray(classlabel);
    mxDestroyArray(nc);
    mxDestroyArray(b);
    mxDestroyArray(w);
    mxDestroyArray(bwratio);
    mxDestroyArray(t1);
    mxDestroyArray(index);
    mxDestroyArray(fisherindex);
    mxDestroyArray(traindata);
    mxDestroyArray(candidateindex);
    mxDestroyArray(invomega);
    mxDestroyArray(invh);
    mxDestroyArray(i);
    mxDestroyArray(looa);
    mxDestroyArray(looac);
    mxDestroyArray(findex);
    mxDestroyArray(j);
    mxDestroyArray(tinvomega);
    mxDestroyArray(alphas);
    mxDestroyArray(tinvh);
    mxDestroyArray(loooutput);
    mxDestroyArray(lcbound);
    mxDestroyArray(tm1);
    mxDestroyArray(tm2);
    mxDestroyArray(boundrecord);
    mxDestroyArray(gamma);
    mxDestroyArray(SelectedFeatureNo);
    mxDestroyArray(data);
    mclSetCurrentLocalFunctionTable(save_local_function_table_);
    return selectindex;
}
