/*
 * MATLAB Compiler: 3.0
 * Date: Thu Apr 06 20:13:28 2006
 * Arguments: "-B" "macro_default" "-O" "all" "-O" "fold_scalar_mxarrays:on"
 * "-O" "fold_non_scalar_mxarrays:on" "-O" "optimize_integer_for_loops:on" "-O"
 * "array_indexing:on" "-O" "optimize_conditionals:on" "-x" "-W" "mex" "-L" "C"
 * "-t" "-T" "link:mexlibrary" "libmatlbmx.mlib" "loosfs" 
 */

#ifndef MLF_V2
#define MLF_V2 1
#endif

#include "libmatlb.h"
#include "loosfs.h"
#include "countele.h"
#include "mean.h"
#include "std.h"

extern _mex_information _mex_info;

static mexFunctionTableEntry function_table[1]
  = { { "loosfs", mlxLoosfs, 3, 1, &_local_function_table_loosfs } };

static _mexInitTermTableEntry init_term_table[1]
  = { { InitializeModule_loosfs, TerminateModule_loosfs } };

/*
 * The function "Mstd" is the MATLAB callback version of the "std" function
 * from file "c:\matlab6p5p1\toolbox\matlab\datafun\std.m". It performs a
 * callback to MATLAB to run the "std" function, and passes any resulting
 * output arguments back to its calling function.
 */
static mxArray * Mstd(int nargout_,
                      mxArray * x,
                      mxArray * flag,
                      mxArray * dim) {
    mxArray * y = NULL;
    mclFevalCallMATLAB(
      mclNVarargout(nargout_, 0, &y, NULL), "std", x, flag, dim, NULL);
    return y;
}

/*
 * The function "Mmean" is the MATLAB callback version of the "mean" function
 * from file "c:\matlab6p5p1\toolbox\matlab\datafun\mean.m". It performs a
 * callback to MATLAB to run the "mean" function, and passes any resulting
 * output arguments back to its calling function.
 */
static mxArray * Mmean(int nargout_, mxArray * x, mxArray * dim) {
    mxArray * y = NULL;
    mclFevalCallMATLAB(
      mclNVarargout(nargout_, 0, &y, NULL), "mean", x, dim, NULL);
    return y;
}

/*
 * The function "Mcountele" is the MATLAB callback version of the "countele"
 * function from file "c:\matlab6p5p1\prtools\knn\countele.m". It performs a
 * callback to MATLAB to run the "countele" function, and passes any resulting
 * output arguments back to its calling function.
 */
static mxArray * Mcountele(mxArray * * element_count,
                           int nargout_,
                           mxArray * in) {
    mxArray * sorted_element = NULL;
    mclFevalCallMATLAB(
      mclNVarargout(nargout_, 0, &sorted_element, element_count, NULL),
      "countele",
      in, NULL);
    return sorted_element;
}

/*
 * The function "mexLibrary" is a Compiler-generated mex wrapper, suitable for
 * building a MEX-function. It initializes any persistent variables as well as
 * a function table for use by the feval function. It then calls the function
 * "mlxLoosfs". Finally, it clears the feval table and exits.
 */
mex_information mexLibrary(void) {
    mclMexLibraryInit();
    return &_mex_info;
}

_mex_information _mex_info
  = { 1, 1, function_table, 0, NULL, 0, NULL, 1, init_term_table };

/*
 * The function "mlfStd" contains the normal interface for the "std" M-function
 * from file "c:\matlab6p5p1\toolbox\matlab\datafun\std.m" (lines 0-0). This
 * function processes any input arguments and passes them to the implementation
 * version of the function, appearing above.
 */
mxArray * mlfStd(mxArray * x, mxArray * flag, mxArray * dim) {
    int nargout = 1;
    mxArray * y = NULL;
    mlfEnterNewContext(0, 3, x, flag, dim);
    y = Mstd(nargout, x, flag, dim);
    mlfRestorePreviousContext(0, 3, x, flag, dim);
    return mlfReturnValue(y);
}

/*
 * The function "mlxStd" contains the feval interface for the "std" M-function
 * from file "c:\matlab6p5p1\toolbox\matlab\datafun\std.m" (lines 0-0). The
 * feval function calls the implementation version of std through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxStd(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[3];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: std Line: 1 Column: 1 The function \"std\""
            " was called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 3) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: std Line: 1 Column: 1 The function \"std\""
            " was called with more than the declared number of inputs (3)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 3 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 3; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    mplhs[0] = Mstd(nlhs, mprhs[0], mprhs[1], mprhs[2]);
    mlfRestorePreviousContext(0, 3, mprhs[0], mprhs[1], mprhs[2]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfMean" contains the normal interface for the "mean"
 * M-function from file "c:\matlab6p5p1\toolbox\matlab\datafun\mean.m" (lines
 * 0-0). This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfMean(mxArray * x, mxArray * dim) {
    int nargout = 1;
    mxArray * y = NULL;
    mlfEnterNewContext(0, 2, x, dim);
    y = Mmean(nargout, x, dim);
    mlfRestorePreviousContext(0, 2, x, dim);
    return mlfReturnValue(y);
}

/*
 * The function "mlxMean" contains the feval interface for the "mean"
 * M-function from file "c:\matlab6p5p1\toolbox\matlab\datafun\mean.m" (lines
 * 0-0). The feval function calls the implementation version of mean through
 * this function. This function processes any input arguments and passes them
 * to the implementation version of the function, appearing above.
 */
void mlxMean(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[2];
    mxArray * mplhs[1];
    int i;
    if (nlhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: mean Line: 1 Column: 1 The function \"mean\""
            " was called with more than the declared number of outputs (1)."),
          NULL);
    }
    if (nrhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: mean Line: 1 Column: 1 The function \"mean"
            "\" was called with more than the declared number of inputs (2)."),
          NULL);
    }
    for (i = 0; i < 1; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 2 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 2; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 2, mprhs[0], mprhs[1]);
    mplhs[0] = Mmean(nlhs, mprhs[0], mprhs[1]);
    mlfRestorePreviousContext(0, 2, mprhs[0], mprhs[1]);
    plhs[0] = mplhs[0];
}

/*
 * The function "mlfCountele" contains the normal interface for the "countele"
 * M-function from file "c:\matlab6p5p1\prtools\knn\countele.m" (lines 0-0).
 * This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
mxArray * mlfCountele(mxArray * * element_count, mxArray * in) {
    int nargout = 1;
    mxArray * sorted_element = NULL;
    mxArray * element_count__ = NULL;
    mlfEnterNewContext(1, 1, element_count, in);
    if (element_count != NULL) {
        ++nargout;
    }
    sorted_element = Mcountele(&element_count__, nargout, in);
    mlfRestorePreviousContext(1, 1, element_count, in);
    if (element_count != NULL) {
        mclCopyOutputArg(element_count, element_count__);
    } else {
        mxDestroyArray(element_count__);
    }
    return mlfReturnValue(sorted_element);
}

/*
 * The function "mlxCountele" contains the feval interface for the "countele"
 * M-function from file "c:\matlab6p5p1\prtools\knn\countele.m" (lines 0-0).
 * The feval function calls the implementation version of countele through this
 * function. This function processes any input arguments and passes them to the
 * implementation version of the function, appearing above.
 */
void mlxCountele(int nlhs, mxArray * plhs[], int nrhs, mxArray * prhs[]) {
    mxArray * mprhs[1];
    mxArray * mplhs[2];
    int i;
    if (nlhs > 2) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: countele Line: 1 Column:"
            " 1 The function \"countele\" was called with m"
            "ore than the declared number of outputs (2)."),
          NULL);
    }
    if (nrhs > 1) {
        mlfError(
          mxCreateString(
            "Run-time Error: File: countele Line: 1 Column:"
            " 1 The function \"countele\" was called with m"
            "ore than the declared number of inputs (1)."),
          NULL);
    }
    for (i = 0; i < 2; ++i) {
        mplhs[i] = NULL;
    }
    for (i = 0; i < 1 && i < nrhs; ++i) {
        mprhs[i] = prhs[i];
    }
    for (; i < 1; ++i) {
        mprhs[i] = NULL;
    }
    mlfEnterNewContext(0, 1, mprhs[0]);
    mplhs[0] = Mcountele(&mplhs[1], nlhs, mprhs[0]);
    mlfRestorePreviousContext(0, 1, mprhs[0]);
    plhs[0] = mplhs[0];
    for (i = 1; i < 2 && i < nlhs; ++i) {
        plhs[i] = mplhs[i];
    }
    for (; i < 2; ++i) {
        mxDestroyArray(mplhs[i]);
    }
}
